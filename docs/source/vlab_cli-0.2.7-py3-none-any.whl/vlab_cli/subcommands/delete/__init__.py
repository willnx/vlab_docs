# -*- coding: UTF-8 -*-
from vlab_cli.subcommands.delete.base import delete
