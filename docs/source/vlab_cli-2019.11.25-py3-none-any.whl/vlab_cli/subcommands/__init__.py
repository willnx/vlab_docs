# -*- coding: UTF-8 -*-
from vlab_cli.subcommands.status import status
from vlab_cli.subcommands.token import token
from vlab_cli.subcommands.init import init
from vlab_cli.subcommands.create import create
from vlab_cli.subcommands.delete import delete
from vlab_cli.subcommands.show import show
from vlab_cli.subcommands.power import power
from vlab_cli.subcommands.connect import connect
from vlab_cli.subcommands.apply import apply
